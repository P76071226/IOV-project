

INSERT INTO susers VALUES (
    NULL,
    'test2',
    password('haya'),
    NULL
    )

